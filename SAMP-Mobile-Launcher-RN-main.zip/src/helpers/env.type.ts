declare module '@env' {
  export const LINK_SITE: string;
  export const LINK_VK: string;
  export const LINK_DISCORD: string;
  export const LINK_TIKTOK: string;
  export const LINK_FORUM_HELP: string;
  export const LINK_SITE_STORAGE: string;
  export const LINK_SITE_NEWS: string;
  export const URL_DISTRIBUTION: string;
  export const URL_NEWS_API: string;
  export const PACKAGE_NAME: string;
  export const PROJECT_NAME: string;
  export const APP_VERSION: string;
  export const SKIP_DOWNLOAD: string;
}
