import { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { Text, View } from 'react-native';
import { DownloadSvg } from '../../assets/svg/index';
import { ButtonLauncher, LoaderContainer } from '../../components';
import { usePermisionFile } from '../../hooks/usePermisionFile';
import { useSpaceDownlload } from '../../hooks/useSpaceDownload';
import { styles } from '../../styles/LoaderStyle';

type InitiationScreenType = NativeStackScreenProps<any>;

export const UpdateStartScreen = React.memo(
  ({ navigation }: InitiationScreenType) => {
    const { fetchPermision } = usePermisionFile();
    const { fetchSpace } = useSpaceDownlload();

    const onPressDownload = () => {
      if (!fetchPermision()) {
        return;
      }

      if (!fetchSpace()) {
        return;
      }

      return navigation.replace('UpdateScreen');
    };

    const onPressCancel = () => navigation.replace('Main');

    return (
      <LoaderContainer>
        <Text style={styles.title}>Update available!</Text>
        <Text style={styles.alert}>
          Press
          <Text style={styles.accent}> update</Text> to confirm
          {'\n'} the file download.
        </Text>
        <View style={styles.buttons}>
          <ButtonLauncher
            btnWidth={'100%'}
            background={'#e0243b'}
            IconLeft={DownloadSvg}
            onPress={onPressDownload}>
            Update
          </ButtonLauncher>
        </View>
        <View style={{ marginTop: 10 }}>
          <ButtonLauncher
            btnWidth={'100%'}
            background={'#34283f'}
            onPress={onPressCancel}>
            Cancel
          </ButtonLauncher>
        </View>
      </LoaderContainer>
    );
  },
);
