import { StackActions } from '@react-navigation/native';
import React from 'react';
import { Text, View } from 'react-native';
import { InstallSvg } from '../../assets/svg/index';
import { ButtonLauncher, LoaderContainer } from '../../components';
import { useAppDispatch } from '../../hooks/useAppDispatch';
import { navigationRef } from '../../routers/RootNavigation';
import { styles } from '../../styles/LoaderStyle';
import { installLauncher } from '../../thunks/launcherTunks';

export const LauncherUpdateScreen = React.memo(() => {
  const dispatch = useAppDispatch();

  const installHandler = React.useCallback(() => {
    dispatch(installLauncher());
  }, []);

  const cancelHandler = React.useCallback(() => {
    navigationRef.current?.dispatch(StackActions.replace('Main'));
  }, []);

  return (
    <LoaderContainer>
      <Text style={[styles.title, styles.titleUppercase]}>
        Launcher update
      </Text>
      <Text style={styles.alert}>
        Press
        <Text style={styles.accent}> update</Text> to confirm
        {'\n'} the launcher update.
      </Text>
      <View style={styles.buttons}>
        <ButtonLauncher
          background={'#e0243b'}
          btnWidth={'100%'}
          IconLeft={InstallSvg}
          onPress={installHandler}>
          Update
        </ButtonLauncher>
      </View>
      <View style={{ marginTop: 10 }}>
        <ButtonLauncher
          btnWidth={'100%'}
          background={'#34283f'}
          onPress={cancelHandler}>
          Cancel
        </ButtonLauncher>
      </View>
    </LoaderContainer>
  );
});
